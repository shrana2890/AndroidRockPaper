package com.example.sukhrana.rockpaperandroidproject;

import android.content.DialogInterface;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.squareup.seismic.ShakeDetector;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;


public class ShakingActivity extends AppCompatActivity implements ShakeDetector.Listener{
    //
    int shakesCount = 0;
    int[] photos = {R.drawable.scissor,R.drawable.paper,R.drawable.rock,R.drawable.lizard,R.drawable.spock};
    String option= "";

    public static final String TAG = "Raman";
    FirebaseFirestore db;

    Random ran = new Random();
    int i = ran.nextInt(photos.length);

    EditText user ;
    String name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shaking);
        SensorManager manager = (SensorManager) getSystemService(SENSOR_SERVICE);
        ShakeDetector detector = new ShakeDetector(this);
        detector.start(manager);
        db = FirebaseFirestore.getInstance();



    }

    public void  WannaPaly(View view){
        user = (EditText)findViewById(R.id.txtName);
        name = user.getText().toString();
        AlertDialog.Builder alert = new AlertDialog.Builder(ShakingActivity.this);
        alert.setMessage("please shake your mobile three times again");
        alert.setNeutralButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(getApplicationContext(),"lets play again",Toast.LENGTH_SHORT).show();

            }
        });
        alert.show();


        i = ran.nextInt(photos.length);
        hearShake();


    }

    @Override
    public void hearShake() {

        shakesCount = shakesCount + 1;
        if (shakesCount >= 3) {
            Log.d("JENELLE", "phone is shaking!!!!");

            Toast.makeText(this, "PHONE IS SHAKING!!!!" + shakesCount, Toast.LENGTH_SHORT).show();
            ImageView image = (ImageView)findViewById(R.id.shakeImage);
            image.setImageResource(photos[i]);
            shakesCount = 0;

            //do code for sending data to each other and then
            if(photos[i] == R.drawable.scissor)
            {
                option = "scissor";
            }
            if(photos[i] == R.drawable.paper)
            {
                option = "paper";
            }
            if(photos[i] == R.drawable.rock)
            {
                option = "rock";
            }
            if(photos[i] == R.drawable.lizard)
            {
                option = "lizard";
            }
            if(photos[i] == R.drawable.spock)
            {
                option = "spock";
            }
            hittingAPI();
            //show who is win and who is loss
            checkWinnerPressed();
        }

    }

    public void hittingAPI() {


        // 4. create a dictionary to store your data
        // - We will be sending this dictionary to Firebase
        Map<String, Object> player = new HashMap<>();
        // player.put("name", name);
        player.put("option", option);
        player.put("name",name);
        //  player.put("phone number",phone);


        //5. connect to firebase
        // Add a new document with a ID = gameID

        final DocumentReference ref = db.collection("games").document();
        ref.set(player)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Log.d(TAG, "Added player choice to game = " + ref.getId());
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.d(TAG, "Error adding document", e);
                    }
                });

    }

    public void checkWinnerPressed() {

        // get outlet
        final TextView t = (TextView) findViewById(R.id.winnerLabel);




        // get player choices from firebase
        //String path = "games/" + gameId;
        db.collection("games")
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            Log.d(TAG,"finished querying firebase");
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                Log.d(TAG, document.getId() + " => " + document.getData());

                                String nameDb = document.getData().get("name").toString();
                                String choiceDb = document.getData().get("option").toString();

                                Log.d(TAG, "++Current player name: " + name);
                                Log.d(TAG, "++Current Player choice: " + option);
                                Log.d(TAG, "++Name from Database:" + nameDb);
                                Log.d(TAG, "++Database Choice:" + choiceDb);


                                // calculate the winner
                                if (nameDb.equals(name)) {
                                    // this is the current player's choice, so skip it
                                    Log.d(TAG, "Names are same, skipping");
                                    t.setText("Waiting for other player choice...");

                                    Log.d(TAG, "----------------");
                                    continue;
                                }
                                else {
                                    Log.d(TAG, "Names are different, calculating winner...");
                                    String winner = "";
                                    // compare user's choice with other player's choice
                                    String player2Choice = document.getData().get("option").toString();


                                    //sukhwinder please do your code here option is first player and player2choice is second player
                                    if(option == "scissor" && player2Choice == "paper"){
                                         Log.d(TAG, "Winner is: " + name);
                                        t.setText("Winner is " + name);
                                        }
                                        else if(option == "paper" && player2Choice == "rock"){
                                         Log.d(TAG, "Winner is: " + name);
                                        t.setText("Winner is " + name);
                                        }
                                        else if(option == "rock" && player2Choice == "lizard"){
                                        Log.d(TAG, "Winner is: " + name);
                                        t.setText("Winner is " + name);
                                        }
                                        else if(option == "lizard" && player2Choice == "spock"){
                                        Log.d(TAG, "Winner is: " + name);
                                        t.setText("Winner is " + name);
                                        }
                                        else if(option == "spock" && player2Choice == "scissor"){
                                        Log.d(TAG, "Winner is: " + name);
                                        t.setText("Winner is " + name);
                                        }
                                        else if (option == "scissor" && player2Choice == "lizard"){
                                        Log.d(TAG, "Winner is: " + name);
                                        t.setText("Winner is " + name);
                                        }
                                        else if (option == "paper" && player2Choice == "spock"){
                                        Log.d(TAG, "Winner is: " + name);
                                        t.setText("Winner is " + name);
                                        }
                                        else if (option == "lizard" && player2Choice == "paper"){
                                      Log.d(TAG, "Winner is: " + name);
                                        t.setText("Winner is " + name);
                                        }
                                        else if (option == "spock" && player2Choice == "rock"){
                                      Log.d(TAG, "Winner is: " + name);
                                        t.setText("Winner is " + name);
                                        }
//                                    else if (option ==  player2Choice ){
//                                        Log.d(TAG, "Winner is: " + name);
//                                       t.setText("Winner is " + name);
//                                    }
                                        else{
                                     Log.d(TAG, "Winner is: " + name);
                                        t.setText("Winner is " + name);
                                        }

                                        // After deciding a winner, enable the button again
                                    Button b = (Button) findViewById(R.id.button);
                                    b.setEnabled(true);


                                    Log.d(TAG, "Winner found,breaking!");
                                    Log.d(TAG, "----------------");

                                    break;
                                }




                            }
                        } else {
                            Log.w(TAG, "Error getting documents.", task.getException());
                        }
                    }
                });





        // show the result in the textview





    }

}

//// calculate the winner
//                                if (nameDb.equals(name)) {
//                                        // this is the current player's choice, so skip it
//                                        Log.d(TAG, "Names are same, skipping");
//                                        t.setText("Waiting for other player choice...");
//
//                                        Log.d(TAG, "----------------");
//                                        continue;
//                                        }
//                                        else {
//                                        Log.d(TAG, "Names are different, calculating winner...");
//                                        String winner = "";
//                                        // compare user's choice with other player's choice
//                                        String player2Choice = document.getData().get("option").toString();
//
//                                        if(option == "scissor" && player2Choice == "paper"){
//                                         Log.d(TAG, "Winner is: " + name);
//                                        t.setText("Winner is " + name);
//                                        }
//                                        else if(option == "paper" && player2Choice == "rock"){
//                                         Log.d(TAG, "Winner is: " + name);
//                                        t.setText("Winner is " + name);
//                                        }
//                                        else if(option == "rock" && player2Choice == "lizard"){
//                                        Log.d(TAG, "Winner is: " + name);
//                                        t.setText("Winner is " + name);
//                                        }
//                                        else if(option == "lizard" && player2Choice == "spock"){
//                                        Log.d(TAG, "Winner is: " + name);
//                                        t.setText("Winner is " + name);
//                                        }
//                                        else if(option == "spock" && player2Choice == "scissor"){
//                                        Log.d(TAG, "Winner is: " + name);
//                                        t.setText("Winner is " + name);
//                                        }
//                                        else if (option == "scissor" && player2Choice == "lizard"){
//                                        Log.d(TAG, "Winner is: " + name);
//                                        t.setText("Winner is " + name);
//                                        }
//                                        else if (option == "paper" && player2Choice == "spock"){
//                                        Log.d(TAG, "Winner is: " + name);
//                                        t.setText("Winner is " + name);
//                                        }
//                                        else if (option == "lizard" && player2Choice == "paper"){
//                                      Log.d(TAG, "Winner is: " + name);
//                                        t.setText("Winner is " + name);
//                                        }
//                                        else if (option == "spock" && player2Choice == "rock"){
//                                      Log.d(TAG, "Winner is: " + name);
//                                        t.setText("Winner is " + name);
//                                        }
////                                    else if (option ==  player2Choice ){
////                                        Log.d(TAG, "Winner is: " + name);
//                                        t.setText("Winner is " + name);
////                                    }
//                                        else{
//                                     Log.d(TAG, "Winner is: " + name);
//                                        t.setText("Winner is " + name);
//                                        }

